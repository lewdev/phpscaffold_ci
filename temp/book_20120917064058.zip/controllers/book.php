<?php
/**
 * Tenrikyo Library
 * @author: Lewis Nakao
 * @company: Tenrikyo Resource
 * @created: 2012-09-17
 * @revised: 2012-09-17
 * Book Controller
 */
class Book extends Controller {
    function Book() {
        parent::Controller();
        $this->load->model('book_model', 'book');
        $this->load->library('validation');
        $this->load->helper('form');
    }

    function index() {
        $this->browse();
    }

    function view($id) {
        $data = array();
        if ($data['book'] = $this->book->get($id)) {
            $data['title'] = "View Book"; // can be '$data['book']['title']'
            $data['book_form'] = $this->book->get_form();
            $this->load->view('layout_header', $data);
            $this->load->view('book/book_actions', $data);
            $this->load->view('book/book_view', $data);
            $this->load->view('layout_footer');
        } else {
            redirect('book/browse');
        }
    } // END view($id)

    function browse($page = 0) {
        $data = array();

        // Get Books
        $page_by = 10;
        $data['title'] = "Browse Books";
        $data['page_type'] = "browse";
        $data['book_form'] = $this->book->get_form();
        $data['book_arr'] = $this->book->get_many($page_by, $page);
        $data['book_total'] = $this->book->count_all();
        if ($page > 0 && empty($data['book_arr']))
            show_404(); // The user has gone too far with paging.

        // Pagination prep
        $this->load->library('pagination');
        $config['base_url'] = site_url('book/browse') .'/';
        $config['total_rows'] = $this->book->count_all();
        $config['per_page'] = $page_by;
        $this->pagination->initialize($config);
        $data['pager'] =& $this->pagination; // Give the view a reference

        $this->load->view('layout_header', $data);
        $this->load->view('book/book_actions', $data);
        $this->load->view('book/book_browse', $data);
        $this->load->view('layout_footer');
    } // END browse($page = 0)

    function trashcan($page = 0) {
        $data = array();

        // Get book trash
        $page_by = 10;
        $data['title'] = "Browse Book Trash Can";
        $data['page_type'] = "trashcan";
        $data['book_form'] = $this->book->get_form();
        $data['book_arr'] = $this->book->get_trash($page_by, $page);
        $data['book_total'] = $this->book->count_trash();
        if ($page > 0 && empty($data['book_arr']))
            show_404(); // The user has gone too far with paging.

        // Pagination prep
        $this->load->library('pagination');
        $config['base_url'] = site_url('book/trashcan') .'/';
        $config['total_rows'] = $this->book->count_trash();
        $config['per_page'] = $page_by;
        $this->pagination->initialize($config);
        $data['pager'] =& $this->pagination; // Give the view a reference

        $this->load->view('layout_header', $data);
        $this->load->view('book/book_actions', $data);
        $this->load->view('book/book_browse', $data);
        $this->load->view('layout_footer');
    } // END trashcan()

    function delete($id) {
        $data = array();
        if ($obj = $this->book->get($id)) {
            $this->book->delete($obj);
            redirect('book/browse');
        } else {
            echo "book ID $id not found.";
        }
    } // END delete($id)

    function trash($id) {
        $data = array();
        if ($obj = $this->book->get($id)) {
            $this->book->trash($obj);
            redirect('book/browse');
        } else {
            echo "book ID $id not found.";
        }
    } // END trash($id)

    function untrash($id) {
        $data = array();
        if ($obj = $this->book->get($id)) {
            $this->book->untrash($obj);
            redirect('book/browse');
        } else {
            echo "book ID $id not found.";
        }
    } // END untrash($id)

    function add() {
        $data = $this->book->get_form();
        $this->validation->set_fields($data['fields']);
        unset($data['rules']['id']);
        $this->validation->set_rules($data['rules']);

        $data['title'] = 'Add a Book';
        $data['action'] = site_url('book/add');
        $data['button_text'] = 'Add Book';

        if ( ! $this->validation->run()) {
            $data['error'] = $this->validation->error_string;
            if ($this->validation->error_string) {
                $data['values'] = $_POST;
            }

            $this->load->view('layout_header', $data);
            $this->load->view('book/book_actions', $data);
            $this->load->view('book/book_form', $data);
            $this->load->view('layout_footer');
        } else {
            if ($this->book->save($_POST)) {
                redirect('book/browse');
            } else {
                $data['error'] = "Don't know why, but it failed";
                $data['values'] = $_POST;
                
                $this->load->view('layout_header', $data);
                $this->load->view('book/book_actions', $data);
                $this->load->view('book/book_form', $data);
                $this->load->view('layout_footer');
            }
        }
    } // END add()

    function edit($id = NULL) {
        if ( ! $book = $this->book->get($id)) {
            show_404();
            return;
        }

        $data = $this->book->get_form();
        $this->validation->set_fields($data['fields']);
        $this->validation->set_rules($data['rules']);

        $data['title'] = 'Edit Book';
        $data['action'] = site_url('book/edit/'. $id);
        $data['button_text'] = 'Save Book';

        $data['values'] = (array) $book;

        if ( ! $this->validation->run()) {
            $data['error'] = $this->validation->error_string;
            if ($this->validation->error_string) {
                $data['values'] = $_POST;
            }
            $this->load->view('layout_header', $data);
            $this->load->view('book/book_actions', $data);
            $this->load->view('book/book_form', $data);
            $this->load->view('layout_footer');
        }
        else
        {
            if ($this->book->save($_POST)) {
                redirect('book/view/'. $id);
            } else {
                $data['error'] = "Don't know why, but it failed";
                $data['error'] .= '<pre>'. print_r($_POST, TRUE) .'</pre>';
                $data['values'] = $_POST;
                $this->load->view('layout_header', $data );
                $this->load->view('book/book_form', $data);
                $this->load->view('layout_footer');
            }
        }
    } // END edit($id = NULL)
} //END class book