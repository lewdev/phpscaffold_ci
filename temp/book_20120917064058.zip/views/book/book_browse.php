<h2><?=$title?></h2>

<? if( isset($book_arr) && count($book_arr)):?>
    <table cellspacing="0" border="1" class="browse_table">
    <tr>
        <th><?=$book_form['fields']['title_sef']?></th>
        <th><?=$book_form['fields']['title_jpn']?></th>
        <th><?=$book_form['fields']['title_jpn_ro']?></th>
        <th><?=$book_form['fields']['target_lang']?></th>
        <th><?=$book_form['fields']['target_title']?></th>
        <th><?=$book_form['fields']['part_type']?></th>
        <th><?=$book_form['fields']['status']?></th>
        <th><?=$book_form['fields']['description']?></th>
        <th><?=$book_form['fields']['created']?></th>
        <th><?=$book_form['fields']['revised']?></th>
        <th>View/Edit/Delete/Trash</th>
    </tr>

    <? foreach ($book_arr as $book) :?>
        <tr>
        <td><?=$book->title_sef?></td>
        <td><?=$book->title_jpn?></td>
        <td><?=$book->title_jpn_ro?></td>
        <td><?=$book->target_lang?></td>
        <td><?=$book->target_title?></td>
        <td><?=$book->part_type?></td>
        <td><?=$book->status?></td>
        <td><?=$book->description?></td>
        <td><?=date("Y-m-d",strtotime($book->created))?></td>
        <td><?=date("Y-m-d",strtotime($book->revised))?></td>

            <td>
              <?=anchor("book/view/". $book->id, 'View')?>
            / <?=anchor("book/edit/". $book->id, 'Edit')?>
            / <?=anchor("book/delete/". $book->id, 'Delete')?>
        <? if( $book->is_active):?>
            / <?=anchor("book/trash/". $book->id, 'Trash')?>
        <? else:?>
            / <?=anchor("book/untrash/". $book->id, 'Untrash')?>
        <? endif;?>
            </td>
        </tr>
    <? endforeach;?>
    </table>
    <div class="pager">
        <?php print $pager->create_links()?>
    </div>
    <p align="right"><strong>Total:</strong> <?=$book_total?> Books
    <p><?=anchor("book/add", "Add a Book")?></p>
<? else:?>
    <? if( $page_type == 'trashcan'):?>
        <p><em>The trash can is empty!</em></p>
    <? else:?>
        <p><em>No records found. Please <?=anchor("book/add", "add a Book")?>.</em></p>
    <? endif;?>
<? endif;?>
