<?php $tabindex = 1;?>
<h2><?=$title?></h2>

<div class="errors">
    <?=$error?>
</div>

<form method="post" action="<?=$action?>"><fieldset>
<?=form_hidden('id', $values['id'])?>

    <div class="form-item">
        <label for="title_sef"><?=$fields['title_sef']?></label>
        <div class="inputtext">
            <?=form_input('title_sef', $values['title_sef'], 'tabindex='.$tabindex++)?>
            <span class="required">* required</span>
        </div>
    </div>
    <div class="form-item">
        <label for="title_jpn"><?=$fields['title_jpn']?></label>
        <div class="inputtext">
            <?=form_input('title_jpn', $values['title_jpn'], 'tabindex='.$tabindex++)?>
            <span class="required">* required</span>
        </div>
    </div>
    <div class="form-item">
        <label for="title_jpn_ro"><?=$fields['title_jpn_ro']?></label>
        <div class="inputtext">
            <?=form_input('title_jpn_ro', $values['title_jpn_ro'], 'tabindex='.$tabindex++)?>
            <span class="required">* required</span>
        </div>
    </div>
    <div class="form-item">
        <label for="target_lang"><?=$fields['target_lang']?></label>
        <div class="inputtext">
            <?=form_input('target_lang', $values['target_lang'], 'tabindex='.$tabindex++)?>
            <span class="required">* required</span>
        </div>
    </div>
    <div class="form-item">
        <label for="target_title"><?=$fields['target_title']?></label>
        <div class="inputtext">
            <?=form_input('target_title', $values['target_title'], 'tabindex='.$tabindex++)?>
            <span class="required">* required</span>
        </div>
    </div>
    <div class="form-item">
        <label for="part_type"><?=$fields['part_type']?></label>
        <?=form_dropdown('part_type', array('Chapter'=>'Chapter','Volume'=>'Volume','Song'=>'Song','Section'=>'Section','Entry'=>'Entry',), $values['part_type'], 'tabindex='.$tabindex++);?>
        <span class="required">* required</span>
    </div>
    <div class="form-item">
        <label for="status"><?=$fields['status']?></label>
        <div class="inputtext">
            <?=form_input('status', $values['status'], 'tabindex='.$tabindex++)?>
            
        </div>
    </div>
    <div class="form-item">
        <label for="description"><?=$fields['description']?></label>
        <div class="textarea">
        <textarea name="description" rows="10" cols="50"
            tabindex="<?=$tabindex++?>"
            ><?=$values['description']?></textarea>
        
        </div>
    </div>
    <p><input type="submit" value="<?=$button_text?>" class="button" tabindex="<?=$tabindex?>" /></p>

</fieldset></form>

<p><?=anchor('book', 'Cancel')?></p>
