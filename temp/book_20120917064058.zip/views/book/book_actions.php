
<div class="actionsnav">
<strong>Book Admin</strong>
<ul>
    <li><?=anchor('book/browse', 'Browse Books')?> </li>
    <li><?=anchor('book/add', 'Add a Book')?></li>
    <li><?=anchor('book/trashcan', 'Trash Can')?></li>
</ul>
</div>
