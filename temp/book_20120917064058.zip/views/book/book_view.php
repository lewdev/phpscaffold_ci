
<h2><?=$title?></h2>
<p align="right">

    <?=anchor('book/edit/'.$book->id, 'Edit')?>
    <?=anchor('book/delete/'.$book->id, 'Delete')?>
    <? if( $book->is_active):?>   
        <?=anchor('book/trash/'.$book->id, 'Trash')?>
    <? else:?>
        <?=anchor('book/untrash/'.$book->id, 'Untrash')?>
    <? endif;?>
</p>
<table cellspacing="0" border="0" class="view_table">
<tr>
    <td><label for="title_sef'"><?=$book_form['fields']['title_sef']?></label></td>
    <td><?=$book->title_sef?></td>
</tr>
<tr>
    <td><label for="title_jpn'"><?=$book_form['fields']['title_jpn']?></label></td>
    <td><?=$book->title_jpn?></td>
</tr>
<tr>
    <td><label for="title_jpn_ro'"><?=$book_form['fields']['title_jpn_ro']?></label></td>
    <td><?=$book->title_jpn_ro?></td>
</tr>
<tr>
    <td><label for="target_lang'"><?=$book_form['fields']['target_lang']?></label></td>
    <td><?=$book->target_lang?></td>
</tr>
<tr>
    <td><label for="target_title'"><?=$book_form['fields']['target_title']?></label></td>
    <td><?=$book->target_title?></td>
</tr>
<tr>
    <td><label for="part_type'"><?=$book_form['fields']['part_type']?></label></td>
    <td><?=$book->part_type?></td>
</tr>
<tr>
    <td><label for="status'"><?=$book_form['fields']['status']?></label></td>
    <td><?=$book->status?></td>
</tr>
<tr>
    <td><label for="description'"><?=$book_form['fields']['description']?></label></td>
    <td><?=$book->description?></td>
</tr>
<tr>
    <td><label for="created'"><?=$book_form['fields']['created']?></label></td>
    <td><?=date("F d, Y H:i A", strtotime($book->created))?></td>
</tr>
<tr>
    <td><label for="revised'"><?=$book_form['fields']['revised']?></label></td>
    <td><?=date("F d, Y H:i A", strtotime($book->revised))?></td>
</tr>
</table>
