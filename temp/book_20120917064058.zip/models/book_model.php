<?php
/**
 * Tenrikyo Library
 * @author: Lewis Nakao
 * @company: Tenrikyo Resource
 * @created: 2012-09-17
 * @revised: 2012-09-17
 * Book Model
 */
class Book_model extends Model {

    function Book_model() {
        parent::Model();
        $this->load->database();
    }

    function get($id) {
        $obj = FALSE;
        if (is_numeric($id)) {
            $this->db->where('id', $id);
            $query = $this->db->get('book');
            if ($query->num_rows() > 0)
                $obj = $query->row();
        }
        return $obj;
    }

    function save($obj) {
        $obj = (object) $obj;

        // Prepare the object (removes non-numbers for integers)
        $obj->id = preg_replace('/[^0-9\.]+/', '', $obj->id);

        return (isset($obj->id) && $obj->id > 0) ? $this->_update($obj) : $result = $this->_create($obj);
    }

    function delete($obj) {
        $this->db->where('id', $obj->id);
        return $this->db->delete('book');
    }
    function trash($obj) {
        $obj->is_active = 0;
        $obj->revised = date("Y-m-d H:i:s", time());
        return $this->save($obj);
    }

    function untrash($obj) {
        $obj->is_active = 1;
        return $this->save($obj);
    }

    function getLastID() {
        $this->db->select('MAX(id) AS last_id');
        $result = $this->db->get('book')->result();
        return $result[0]->last_id;
    }

    function _create($obj) {
        $obj = (object) $obj;
        $obj->is_active = 1;
        $obj->created = date("Y-m-d H:i:s", time());
        $obj->revised = $obj->created;
        return $this->db->insert('book', $obj);
    }

    function _update($obj) {
        $obj = (object) $obj;
        $obj->revised = date("Y-m-d H:i:s", time());
        $this->db->where('id', $obj->id);
        return $this->db->update('book', $obj);
    }

    function _delete($obj) {
        $obj = (object) $obj;
        $this->db->where('id', $obj->id);
        return $this->db->delete('book', $obj);
    }

    function get_many($limit = 10, $offset = 0) {
        $objs = array();
        $this->db->limit($limit);
        $this->db->offset($offset);
        $this->db->where('is_active', 1);
        $this->db->order_by('created', 'desc');
        $query = $this->db->get('book');
        if ($query->num_rows() > 0) {
            $objs = $query->result();
        }
        return $objs;
    }

    function get_trash($limit = 10, $offset = 0) {
        $objs = array();
        $this->db->limit($limit);
        $this->db->offset($offset);
        $this->db->where('is_active', 0);
        $this->db->order_by('created', 'desc');
        $query = $this->db->get('book');
        if ($query->num_rows() > 0) {
            $objs = $query->result();
        }
        return $objs;
    }

    function count_all() {
        $this->db->select('COUNT(id) AS count_all');
        $this->db->where('is_active', 1);
        $result = $this->db->get('book')->result();
        return $result[0]->count_all;
    }

    function count_trash() {
        $this->db->select('COUNT(id) AS count_all');
        $this->db->where('is_active', 0);
        $result = $this->db->get('book')->result();
        return $result[0]->count_all;
    }

    function get_form() {
        $form = array(
            'fields' => array(
                'title_sef' => 'Title Sef', // SEF title, to appear on URL (i.e. 'osashizu', 'ofudesaki', 'mikagura-uta', 'kyosoden')
                'title_jpn' => 'Title Jpn',
                'title_jpn_ro' => 'Title Jpn Ro',
                'target_lang' => 'Target Lang',
                'target_title' => 'Target Title',
                'part_type' => 'Part Type',
                'status' => 'Status', // draft, published
                'description' => 'Description', // should have descriptions in every language and describe the translated title.
                'created' => 'Created',
                'revised' => 'Revised',
                'is_active' => 'Is Active',
            ),
            // rules: required|trim|exact_length[4]|max_length[n]|min_length[n]|matches[form_item]
            //    valid_email|valid_emails|numeric|integer|options[]|alpha|alpha_numeric|alpha_dash|
            'rules' => array( 
                'title_sef' => 'required|trim|htmlspecialchars|max_length[127]',
                'title_jpn' => 'required|trim|htmlspecialchars|max_length[255]',
                'title_jpn_ro' => 'required|trim|htmlspecialchars|max_length[255]',
                'target_lang' => 'required|trim|htmlspecialchars|max_length[7]',
                'target_title' => 'required|trim|htmlspecialchars|max_length[255]',
                'part_type' => 'required',
                'status' => 'trim|htmlspecialchars|max_length[45]',
                'description' => 'xss_clean',
                'created' => '',
                'revised' => '',
                'is_active' => '',
            ),
            'values' => array( // default values
                'id' => '',
                'title_sef' => '',
                'title_jpn' => '',
                'title_jpn_ro' => '',
                'target_lang' => '',
                'target_title' => '',
                'part_type' => '',
                'status' => '',
                'description' => '',
                'created' => '',
                'revised' => '',
                'is_active' => '',
            ),
        );
        return $form;
    } //END get_form()
}